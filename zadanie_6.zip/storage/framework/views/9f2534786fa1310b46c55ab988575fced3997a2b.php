

<?php
$title='Список новостей'
?>

<?php $__env->startSection('title'); ?>
<?php echo e($title); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
<h1 class="display-4 text-center"><?php echo e($title); ?></h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('menu'); ?>
<?php echo $__env->make('admin.components.menu', ['all_categories' => $all_categories], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="mt-2 p-2 d-flex flex-wrap justify-content-around">
    <?php $__empty_1 = true; $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

    <div class="col-8 mt-2 d-flex border border-secondary">
    <div class="col-2 mt-2"> <img src="/images/no_photo.jpg" class="card-img-top" alt="<?php echo e($item['title']); ?>">  </div>
     <div class="col-8 mt-2 p-2"><h5><?php echo e($item['title']); ?></h5> <p><?php echo e($item['short_discraption']); ?></p></div>
     <div class="col-2 mt-2 p-2">
        <a href="<?php echo e(route('admin.edit_news', $item['id'])); ?>" class="btn btn-primary mb-2 w-100">Редактировать</a><br>
        <form method="POST" action="<?php echo e(route('admin.delete_news')); ?>">
        <?php echo csrf_field(); ?>
        <!-- <a href="<?php echo e(route('admin.delete_news', $item['id'])); ?>" class="btn btn-danger mt-2">Удалить</a> -->
        <input name="delete_id" type="hidden" value="<?php echo e($item['id']); ?>">
        <button type="submit" class="btn btn-danger mt-2 w-100">Удалить</button>
        </form>
    </div>
    </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <div class="p-3 mb-2 bg-light">Нет новостей</div>
    <?php endif; ?>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<?php echo $__env->make('components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\PROGRAM\OpenServer\domains\kurslaravel1.local\resources\views/admin/listnews.blade.php ENDPATH**/ ?>