<!DOCTYPE html>
<html lang="ru">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <!-- <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js"></script> -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/sass/app.scss', 'resources/js/app.js']); ?>
    <title><?php echo $__env->yieldContent('title'); ?></title>
</head>

<body>
    <?php echo $__env->yieldContent('menu'); ?>
    <?php echo $__env->yieldContent('header'); ?>
    <div class="mb-5 pb-5">
            <?php echo $__env->yieldContent('content'); ?>
    </div>
    <?php echo $__env->yieldContent('footer'); ?>
</body>

</html><?php /**PATH E:\PROGRAM\OpenServer\domains\kurslaravel1.local\resources\views/layouts/main.blade.php ENDPATH**/ ?>