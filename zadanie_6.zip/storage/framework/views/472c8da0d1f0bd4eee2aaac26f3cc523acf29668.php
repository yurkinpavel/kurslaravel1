

<?php if(!$news): ?>
<?php $__env->startSection('title'); ?>
<?php echo e($title='Извините, нет такой новости'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="mt-2 p-2 text-center col-6 m-auto text-dark bg-warning">
    <div class="p-3 mb-2">Извините, нет такой новости</div>
</div>
<?php $__env->stopSection(); ?>
<?php else: ?>
<?php $__env->startSection('title'); ?>
<?php echo e($title=$news['title']); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="mt-2 p-2 col-6 m-auto">
    <?php if($news): ?>
    <?php if(!$news['is_private']): ?>
    <div class="card  mt-2 mx-2">
        <img src="/images/no_photo.jpg" class="card-img-top" alt="панорама">
        <div class="card-body">
            <h5 class="card-title  text-center "><?php echo e($news['title']); ?></h5>
            <p class="card-text"><?php echo e($news['text']); ?></p>
        </div>
    </div>
    <?php else: ?>
    <h5>Зарегистрируйтесь для просмотра</h5>
    <?php endif; ?>


    <?php else: ?>
    <h5>Такой новости не существует</h5>
    <?php endif; ?>

</div>
<?php $__env->stopSection(); ?>
<?php endif; ?>

<?php $__env->startSection('header'); ?>
<h1 class="text-center"><?php echo e($title); ?></h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('menu'); ?>
<?php echo $__env->make('components.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<?php echo $__env->make('components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\PROGRAM\OpenServer\domains\kurslaravel1.local\resources\views/news/one.blade.php ENDPATH**/ ?>